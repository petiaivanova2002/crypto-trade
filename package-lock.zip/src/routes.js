const router = require('express').Router();

const homeController = require('./controllers/homeController');
const authController = require('./controllers/authController');
const cryptoController = require('./controllers/cryptoController')
const { isAuth } = require('./middlewares/authMiddleware');

router.get('/', homeController.getHomePage);

router.get('/register', authController.getRegisterPage);
router.post('/register', authController.postRegisterPage);
router.get('/login', authController.getLoginPage);
router.post('/login', authController.postLoginPage);
router.get('/logout', isAuth, authController.logoutPage);

router.get('/catalog', cryptoController.getAllCryptos);
router.get('/catalog/:cryptoId/details', cryptoController.getCryptoDetails);
router.get('/create', cryptoController.getCreateCrypto);
router.post('/create', cryptoController.postCreateCrypto);
router.get('/catalog/:cryptoId/edit', cryptoController.getEditPage);
router.post('/catalog/:cryptoId/edit', cryptoController.postUpdateCrypto);
router.get('/catalog/:cryptoId/delete', cryptoController.postDeleteCrypto);
router.get('/catalog/:cryptoId/buy', cryptoController.getBoughtCrypto);


module.exports = router;