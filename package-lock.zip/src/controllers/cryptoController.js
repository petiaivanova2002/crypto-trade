

const Crypto = require('../models/Crypto');
const cryptoService = require('../services/cryptoService')
const cryptoUtils = require('../utils/cryptoUtils');
const { getErrorMessage } = require('../utils/errorUtils')

exports.getAllCryptos = async (req, res) => {
    const cryptos = await Crypto.find({}).lean();
    res.render('home/catalog', { cryptos });
};

exports.getCryptoDetails = async (req, res) => {
    const crypto = await Crypto.findById(req.params.cryptoId).lean();
    if (!req.user) {
        res.render('crypto/details', { crypto });
    } else {
        const isOwner = cryptoUtils.isOwner(crypto, req.user);

        const isBuyer = cryptoUtils.isBuyer(crypto, req.user);

        res.render('crypto/details', { crypto, isOwner, isBuyer });
    };

};

exports.getCreateCrypto = (req, res) => {
    res.render('crypto/create');
};

exports.postCreateCrypto = async (req, res) => {
    const { name, image, price, description, payment } = req.body;

    try {
        const crypto = await Crypto.create({ name, image, price, description, payment, buyer: [], owner: req.user._id });
        res.redirect('/catalog');
    } catch (error) {
        return res.status(401).render('crypto/create', { error: getErrorMessage(error) })
    }

};

exports.getEditPage = async (req, res) => {
    const crypto = await Crypto.findById(req.params.cryptoId).lean();
    const paymentMethods = cryptoUtils.generatePayments(crypto.payment);

    if (!cryptoUtils.isOwner(crypto, req.user)) {
        return res.redirect('/404')
    }

    res.render('crypto/edit', { crypto, paymentMethods })
}

exports.getDeletePage = async (req, res) => {

    const crypto = await Crypto.findById(req.params.cryptoId).lean();
    const paymentMethods = cryptoUtils.generatePayments(crypto.payment);

    res.render('crypto/delete', { crypto, paymentMethods })
};

exports.postUpdateCrypto = async (req, res) => {
    const { name, image, price, description, payment } = req.body;

    await cryptoService.updatePage(req.params.cryptoId, { name, image, price, description, payment });

    res.redirect(`/catalog/${req.params.cryptoId}/details`);
};

exports.postDeleteCrypto = async (req, res) => {
    await cryptoService.delete(req.params.cryptoId);
    res.redirect('/catalog')
};

exports.getBoughtCrypto = async (req, res) => {
    const crypto = await Crypto.findById(req.params.cryptoId).lean();
    let isBuyer = cryptoUtils.isBuyer(crypto, req.user);
    const userId = req.user._id
    crypto.buyer.push(userId);
    console.log(crypto)
    console.log(crypto.buyer);
    isBuyer = false;


    res.render(`crypto/details`, { crypto, isBuyer })
}